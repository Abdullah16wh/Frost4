# Frost

Minimal, liquid-glass home screen for Android 16 (API 36), tuned for the RedMagic 10 Pro.
Glass effects use the Kyant0 backdrop library (blur, vibrancy and lens refraction).

- Clock + date on a minimal wallpaper, nothing else
- Liquid glass dock that refracts the wallpaper behind it
- Swipe up, or tap the glass dot, for the app drawer (frosted sheet + search)
- Long-press an app in the drawer to pin or unpin it in the dock (max 5)
- Long-press empty space on the home screen to choose a wallpaper from your gallery

## Build (no computer): GitHub Actions

Upload this zip plus `.github/workflows/build.yml` to a GitHub repo, run the
"Build APK" workflow, then download the artifact.

## Build (Android Studio)

Open the folder, sync, press Run. Press Home on the phone and choose "Frost" > Always.

## Notes

- Needs Android 13+ (lens refraction). Glass only refracts the launcher's own wallpaper, not the system one.
- It replaces the home screen only, not the status bar or quick settings. No root.
- All library calls live in `ui/Glass.kt`.
