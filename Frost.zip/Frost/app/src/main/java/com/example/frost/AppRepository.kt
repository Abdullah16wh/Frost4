package com.example.frost

import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.core.graphics.drawable.toBitmap

data class AppEntry(
    val label: String,
    val packageName: String,
    val icon: ImageBitmap,
)

object AppRepository {

    fun loadApps(context: Context): List<AppEntry> {
        val pm = context.packageManager
        val intent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        return pm.queryIntentActivities(intent, 0)
            .asSequence()
            .filter { it.activityInfo.packageName != context.packageName }
            .map { info ->
                val bmp: Bitmap = info.loadIcon(pm).toBitmap(144, 144)
                AppEntry(
                    label = info.loadLabel(pm).toString(),
                    packageName = info.activityInfo.packageName,
                    icon = bmp.asImageBitmap(),
                )
            }
            .distinctBy { it.packageName }
            .sortedBy { it.label.lowercase() }
            .toList()
    }

    fun launch(context: Context, packageName: String) {
        context.packageManager.getLaunchIntentForPackage(packageName)?.let {
            it.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            context.startActivity(it)
        }
    }

    // --- Wallpaper (the launcher draws its own so the glass can refract it) ---

    private const val WALLPAPER_FILE = "wallpaper.jpg"
    private const val MAX_SIDE = 2400

    fun loadWallpaper(context: Context): ImageBitmap? {
        val file = java.io.File(context.filesDir, WALLPAPER_FILE)
        if (!file.exists()) return null
        return android.graphics.BitmapFactory.decodeFile(file.path)?.asImageBitmap()
    }

    /** Copies a picked image into app storage, downscaled, and returns it. */
    fun saveWallpaper(context: Context, uri: android.net.Uri): ImageBitmap? {
        val resolver = context.contentResolver
        val bounds = android.graphics.BitmapFactory.Options().apply { inJustDecodeBounds = true }
        resolver.openInputStream(uri)?.use { android.graphics.BitmapFactory.decodeStream(it, null, bounds) }
        var sample = 1
        while (maxOf(bounds.outWidth, bounds.outHeight) / sample > MAX_SIDE) sample *= 2
        val opts = android.graphics.BitmapFactory.Options().apply { inSampleSize = sample }
        val bmp = resolver.openInputStream(uri)?.use {
            android.graphics.BitmapFactory.decodeStream(it, null, opts)
        } ?: return null
        java.io.File(context.filesDir, WALLPAPER_FILE).outputStream().use {
            bmp.compress(Bitmap.CompressFormat.JPEG, 92, it)
        }
        return bmp.asImageBitmap()
    }

    // --- Pinned dock apps (stored as a comma-separated list) ---

    private const val PREFS = "frost_prefs"
    private const val KEY_PINS = "pins"
    const val MAX_PINS = 5

    fun loadPins(context: Context): List<String> =
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .getString(KEY_PINS, "").orEmpty()
            .split(",").filter { it.isNotBlank() }

    fun savePins(context: Context, pins: List<String>) {
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .edit().putString(KEY_PINS, pins.joinToString(",")).apply()
    }
}
