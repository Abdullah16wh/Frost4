package com.example.frost.ui

import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.gestures.detectVerticalDragGestures
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.layout.ContentScale
import com.example.frost.AppEntry
import com.example.frost.AppRepository
import com.kyant.backdrop.Backdrop
import com.kyant.backdrop.backdrops.layerBackdrop
import com.kyant.backdrop.backdrops.rememberLayerBackdrop
import kotlinx.coroutines.delay
import java.time.LocalDateTime
import java.time.format.DateTimeFormatter
import java.util.Locale

private val White = Color.White

@Composable
fun HomeScreen(
    apps: List<AppEntry>,
    pins: List<String>,
    wallpaper: ImageBitmap?,
    onPinsChange: (List<String>) -> Unit,
    drawerOpen: Boolean,
    onDrawerChange: (Boolean) -> Unit,
    onPickWallpaper: () -> Unit,
) {
    val context = LocalContext.current
    var dragTotal by remember { mutableStateOf(0f) }

    // The backdrop is what the glass blurs and refracts: our wallpaper layer below
    val backdrop = rememberLayerBackdrop {
        drawRect(Color.Black)
        drawContent()
    }

    BackHandler(enabled = drawerOpen) { onDrawerChange(false) }

    Box(
        Modifier
            .fillMaxSize()
            .pointerInput(drawerOpen) {
                if (!drawerOpen) {
                    detectVerticalDragGestures(
                        onDragStart = { dragTotal = 0f },
                        onDragEnd = { if (dragTotal < -120f) onDrawerChange(true) },
                    ) { _, dy -> dragTotal += dy }
                }
            }
            .pointerInput(drawerOpen) {
                // Long-press empty space to choose a wallpaper
                if (!drawerOpen) detectTapGestures(onLongPress = { onPickWallpaper() })
            }
    ) {
        Wallpaper(wallpaper, Modifier.layerBackdrop(backdrop))

        // ---- Home: just a clock, a date and the dock ----
        Column(
            Modifier
                .fillMaxSize()
                .statusBarsPadding()
                .navigationBarsPadding()
                .padding(horizontal = 24.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
        ) {
            Clock(Modifier.padding(top = 96.dp))
            Box(Modifier.weight(1f))
            Dock(
                backdrop = backdrop,
                apps = apps,
                pins = pins,
                onLaunch = { AppRepository.launch(context, it) },
                onOpenDrawer = { onDrawerChange(true) },
            )
            Box(Modifier.size(16.dp))
        }

        // ---- App drawer ----
        AnimatedVisibility(
            visible = drawerOpen,
            enter = fadeIn() + slideInVertically { it / 6 },
            exit = fadeOut() + slideOutVertically { it / 6 },
        ) {
            Drawer(
                backdrop = backdrop,
                apps = apps,
                pins = pins,
                onPinsChange = onPinsChange,
                onLaunch = {
                    AppRepository.launch(context, it)
                    onDrawerChange(false)
                },
            )
        }
    }
}

@Composable
private fun Clock(modifier: Modifier = Modifier) {
    val now by produceState(LocalDateTime.now()) {
        while (true) {
            value = LocalDateTime.now()
            delay(1_000)
        }
    }
    val shadow = androidx.compose.ui.graphics.Shadow(Color(0x40000000), blurRadius = 12f)
    Column(modifier, horizontalAlignment = Alignment.CenterHorizontally) {
        Text(
            text = now.format(DateTimeFormatter.ofPattern("HH:mm")),
            style = TextStyle(
                color = White,
                fontSize = 84.sp,
                fontWeight = FontWeight.ExtraLight,
                letterSpacing = (-2).sp,
                shadow = shadow,
            ),
        )
        Text(
            text = now.format(DateTimeFormatter.ofPattern("EEEE, d MMMM", Locale.getDefault())),
            style = TextStyle(
                color = White.copy(alpha = 0.78f),
                fontSize = 16.sp,
                fontWeight = FontWeight.Light,
                letterSpacing = 0.5.sp,
                shadow = shadow,
            ),
        )
    }
}

/** Default minimalist wallpaper: deep gradient with soft glows (so the glass has something to refract). */
@Composable
private fun Wallpaper(image: ImageBitmap?, modifier: Modifier = Modifier) {
    Box(modifier.fillMaxSize()) {
        if (image != null) {
            Image(
                bitmap = image,
                contentDescription = null,
                contentScale = ContentScale.Crop,
                modifier = Modifier.fillMaxSize(),
            )
        } else {
            Box(
                Modifier.fillMaxSize().background(
                    Brush.linearGradient(listOf(Color(0xFF0A0F1E), Color(0xFF16254A), Color(0xFF2B2150)))
                )
            )
            Box(
                Modifier.fillMaxSize().background(
                    Brush.radialGradient(
                        listOf(Color(0x664C7DFF), Color.Transparent),
                        center = androidx.compose.ui.geometry.Offset(250f, 700f),
                        radius = 900f,
                    )
                )
            )
            Box(
                Modifier.fillMaxSize().background(
                    Brush.radialGradient(
                        listOf(Color(0x55B05CFF), Color.Transparent),
                        center = androidx.compose.ui.geometry.Offset(900f, 1700f),
                        radius = 1000f,
                    )
                )
            )
        }
    }
}

@Composable
private fun Dock(
    backdrop: Backdrop,
    apps: List<AppEntry>,
    pins: List<String>,
    onLaunch: (String) -> Unit,
    onOpenDrawer: () -> Unit,
) {
    val pinned = pins.mapNotNull { p -> apps.firstOrNull { it.packageName == p } }
    Row(
        Modifier
            .liquidGlass(backdrop, DockShape)
            .padding(horizontal = 20.dp, vertical = 14.dp),
        horizontalArrangement = Arrangement.spacedBy(18.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        pinned.forEach { app ->
            Image(
                bitmap = app.icon,
                contentDescription = app.label,
                modifier = Modifier
                    .size(52.dp)
                    .clip(RoundedCornerShape(16.dp))
                    .combinedClickable(onClick = { onLaunch(app.packageName) }),
            )
        }
        // All-apps button: a quiet glass dot
        Box(
            Modifier
                .size(44.dp)
                .liquidGlass(
                    backdrop, CircleShape,
                    blurDp = 2f, lensHeightDp = 8f, lensAmountDp = 16f, tint = 0.16f,
                )
                .combinedClickable(
                    interactionSource = remember { MutableInteractionSource() },
                    indication = null,
                    onClick = onOpenDrawer,
                ),
            contentAlignment = Alignment.Center,
        ) {
            Box(Modifier.size(8.dp).clip(CircleShape).background(White.copy(alpha = 0.9f)))
        }
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
private fun Drawer(
    backdrop: Backdrop,
    apps: List<AppEntry>,
    pins: List<String>,
    onPinsChange: (List<String>) -> Unit,
    onLaunch: (String) -> Unit,
) {
    var query by remember { mutableStateOf("") }
    val filtered = remember(query, apps) {
        if (query.isBlank()) apps
        else apps.filter { it.label.contains(query.trim(), ignoreCase = true) }
    }

    Column(
        Modifier
            .fillMaxSize()
            .frostedPanel(backdrop)
            .statusBarsPadding()
            .navigationBarsPadding()
            .padding(horizontal = 20.dp)
    ) {
        BasicTextField(
            value = query,
            onValueChange = { query = it },
            singleLine = true,
            textStyle = TextStyle(color = White, fontSize = 16.sp, fontWeight = FontWeight.Light),
            cursorBrush = SolidColor(White),
            modifier = Modifier
                .padding(top = 24.dp, bottom = 16.dp)
                .fillMaxWidth()
                .glass(RoundedCornerShape(28.dp), strength = 0.12f)
                .padding(horizontal = 20.dp, vertical = 14.dp),
            decorationBox = { inner ->
                Box {
                    if (query.isEmpty()) {
                        Text("Search", color = White.copy(alpha = 0.55f), fontSize = 16.sp, fontWeight = FontWeight.Light)
                    }
                    inner()
                }
            },
        )

        LazyVerticalGrid(
            columns = GridCells.Fixed(4),
            verticalArrangement = Arrangement.spacedBy(20.dp),
            modifier = Modifier.fillMaxSize(),
        ) {
            items(filtered, key = { it.packageName }) { app ->
                val isPinned = app.packageName in pins
                Column(
                    Modifier
                        .combinedClickable(
                            onClick = { onLaunch(app.packageName) },
                            // Long-press toggles the dock pin
                            onLongClick = {
                                val next = if (isPinned) pins - app.packageName
                                else (pins + app.packageName).takeLast(AppRepository.MAX_PINS)
                                onPinsChange(next)
                            },
                        ),
                    horizontalAlignment = Alignment.CenterHorizontally,
                ) {
                    Image(
                        bitmap = app.icon,
                        contentDescription = app.label,
                        modifier = Modifier.size(56.dp).clip(RoundedCornerShape(18.dp)),
                    )
                    Text(
                        text = app.label + if (isPinned) " •" else "",
                        color = White.copy(alpha = 0.9f),
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Light,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                        textAlign = TextAlign.Center,
                        modifier = Modifier.padding(top = 6.dp),
                    )
                }
            }
        }
    }
}
