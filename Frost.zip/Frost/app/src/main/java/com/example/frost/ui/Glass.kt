package com.example.frost.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.shape.CornerBasedShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.RectangleShape
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.unit.dp
import com.kyant.backdrop.Backdrop
import com.kyant.backdrop.drawBackdrop
import com.kyant.backdrop.effects.blur
import com.kyant.backdrop.effects.lens
import com.kyant.backdrop.effects.vibrancy

/*
 * All use of the Kyant0 backdrop library lives in this file, so if a library
 * signature ever differs, this is the only place to fix.
 */

private val rim = Brush.linearGradient(
    listOf(
        Color.White.copy(alpha = 0.60f),
        Color.White.copy(alpha = 0.06f),
        Color.White.copy(alpha = 0.28f),
    )
)

/** Liquid glass: blurs and refracts whatever the backdrop (our wallpaper) shows behind it. */
fun Modifier.liquidGlass(
    backdrop: Backdrop,
    shape: CornerBasedShape,
    blurDp: Float = 4f,
    lensHeightDp: Float = 16f,
    lensAmountDp: Float = 32f,
    tint: Float = 0.10f,
): Modifier = this
    .drawBackdrop(
        backdrop = backdrop,
        shape = { shape },
        effects = {
            vibrancy()
            blur(blurDp.dp.toPx())
            lens(lensHeightDp.dp.toPx(), lensAmountDp.dp.toPx())
        },
        onDrawSurface = { drawRect(Color.White.copy(alpha = tint)) },
    )
    .border(1.dp, rim, shape)

/** Full-width frosted sheet (used behind the app drawer): blur and vibrancy, no lens. */
fun Modifier.frostedPanel(backdrop: Backdrop): Modifier = this
    .drawBackdrop(
        backdrop = backdrop,
        shape = { RectangleShape },
        effects = {
            vibrancy()
            blur(36f.dp.toPx())
        },
        onDrawSurface = { drawRect(Color.Black.copy(alpha = 0.32f)) },
    )

/** Cheap glass (no backdrop) for small controls like the search field. */
fun Modifier.glass(shape: Shape, strength: Float = 0.14f): Modifier = this
    .shadow(elevation = 12.dp, shape = shape, ambientColor = Color(0x33000000), spotColor = Color(0x22000000))
    .clip(shape)
    .background(
        Brush.verticalGradient(
            listOf(
                Color.White.copy(alpha = strength + 0.10f),
                Color.White.copy(alpha = strength),
                Color.White.copy(alpha = strength * 0.7f),
            )
        )
    )
    .border(1.dp, rim, shape)

val DockShape = RoundedCornerShape(36.dp)
